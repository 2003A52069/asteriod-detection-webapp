# ASTEROID_DETECTION_WEBAPP
This is a machine learning webapp that predicts if an asteroid can be hazardous to our planet
